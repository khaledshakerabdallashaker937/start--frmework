import { Component } from '@angular/core';

@Component({
  selector: 'app-startframework',
  standalone: true,
  imports: [],
  templateUrl: './startframework.component.html',
  styleUrl: './startframework.component.css'
})
export class StartframeworkComponent {

}
