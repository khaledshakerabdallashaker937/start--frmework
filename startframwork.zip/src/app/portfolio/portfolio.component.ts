import { Component } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  standalone: true,
  imports: [],
  templateUrl: './portfolio.component.html',
  styleUrl: './portfolio.component.css'
})
export class PortfolioComponent {

isHidden:boolean = true;

modelImg:string ='';


imgSrc:String[] = [

  '../../assets/images/one.jpg',
  '../../assets/images/img10.png',
  '../../assets/images/cars/1.jpg',
  '../../assets/images/gallery/meal-3.jpg',
  '../../assets/images/cars/2.jpg',
  '../../assets/images/cars/3.jpg',
];
hideModel(eleTarget:EventTarget | null ,imgRef:HTMLImageElement):void{
  if(eleTarget == imgRef ) {
return;
  
  }else{

    this.isHidden = true;

  }

}

}
